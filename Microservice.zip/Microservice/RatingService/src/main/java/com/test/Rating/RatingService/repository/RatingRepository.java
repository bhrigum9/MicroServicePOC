package com.test.Rating.RatingService.repository;

import com.test.Rating.RatingService.entities.Ratings;
import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.data.mongodb.repository.Query;

import java.util.List;

/**
 * The interface Rating repository.
 */
public interface RatingRepository extends MongoRepository<Ratings, String> {

    //Custom Methods
    List<Ratings> findByUserId(String userId);

    List<Ratings> findByHotelId(String hotelId);
}

