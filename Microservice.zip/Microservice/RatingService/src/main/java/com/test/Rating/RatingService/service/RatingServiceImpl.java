package com.test.Rating.RatingService.service;

import com.test.Rating.RatingService.entities.Ratings;
import com.test.Rating.RatingService.repository.RatingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class RatingServiceImpl implements RatingService {
    @Autowired
    private RatingRepository ratingRepository;

    /**
     * @param ratings the ratings
     * @return
     */
    @Override
    public Ratings createRating(Ratings ratings) {
        return ratingRepository.save(ratings);
    }

    /**
     * @return
     */
    @Override
    public List<Ratings> getAllRatings() {
        return ratingRepository.findAll();
    }

    /**
     * @param hotelId the hotel id
     * @return
     */
    @Override
    public List<Ratings> getRatingByHotelId(String hotelId) {
        return ratingRepository.findByHotelId(hotelId);
    }

    /**
     * @param userId the user id
     * @return
     */
    @Override
    public List<Ratings> getRatingByUserId(String userId) {
        return ratingRepository.findByUserId(userId);
    }

    /**
     * @param id the id
     */
    @Override
    public void deleteById(String id) {
        ratingRepository.deleteById(id);
    }
}
