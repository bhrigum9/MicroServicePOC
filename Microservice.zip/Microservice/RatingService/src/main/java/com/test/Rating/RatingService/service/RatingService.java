package com.test.Rating.RatingService.service;

import com.test.Rating.RatingService.entities.Ratings;

import java.util.List;

/**
 * The interface Rating service.
 */
public interface RatingService {

    /**
     * Create rating ratings.
     *
     * @param ratings the ratings
     * @return the ratings
     */
    public Ratings createRating(Ratings ratings);

    /**
     * Gets all ratings.
     *
     * @return the all ratings
     */
    public List<Ratings> getAllRatings();

    /**
     * Gets rating by hotel id.
     *
     * @param hotelId the hotel id
     * @return the rating by hotel id
     */
    public List<Ratings> getRatingByHotelId(String hotelId);

    /**
     * Gets rating by user id.
     *
     * @param userId the user id
     * @return the rating by user id
     */
    public List<Ratings> getRatingByUserId(String userId);

    /**
     * Delete rating.
     *
     * @param id the id
     */
    public void deleteById(String id);



}
