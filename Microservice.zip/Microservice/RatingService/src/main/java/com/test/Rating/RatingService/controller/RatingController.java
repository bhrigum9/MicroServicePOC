package com.test.Rating.RatingService.controller;

import com.test.Rating.RatingService.entities.Ratings;
import com.test.Rating.RatingService.service.RatingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * The type Rating controller.
 */
@RestController
@RequestMapping("/ratings")
public class RatingController {
    @Autowired
    private RatingService ratingService;

    /**
     * Create rating response entity.
     *
     * @param ratings the ratings
     * @return the response entity
     */
    @PostMapping
    public ResponseEntity<Ratings> createRating(@RequestBody Ratings ratings) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ratingService.createRating(ratings));
    }

    /**
     * Gets all ratings.
     *
     * @return the all ratings
     */
    @GetMapping
    public ResponseEntity<List<Ratings>> getAllRatings() {
        return ResponseEntity.status(HttpStatus.CREATED).body(ratingService.getAllRatings());
    }

    /**
     * Gets rating by user id.
     *
     * @param userId the user id
     * @return the rating by user id
     */
    @GetMapping("/users/{userId}")
    public ResponseEntity<List<Ratings>> getRatingByUserId(@PathVariable String userId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ratingService.getRatingByUserId(userId));
    }

    /**
     * Gets rating by hotelk id.
     *
     * @param hotelId the hotel id
     * @return the rating by hotelk id
     */
    @GetMapping("/hotels/{hotelId}")
    public ResponseEntity<List<Ratings>> getRatingByHotelId(@PathVariable String hotelId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(ratingService.getRatingByHotelId(hotelId));
    }

    /**
     * Delete user response entity.
     *
     * @param id the id
     * @return the response entity
     */
    @DeleteMapping("/{id}")
    public ResponseEntity deleteById(@PathVariable("id") String id){
        ratingService.deleteById(id);
        return ResponseEntity.ok(HttpStatus.ACCEPTED);
    }
}
