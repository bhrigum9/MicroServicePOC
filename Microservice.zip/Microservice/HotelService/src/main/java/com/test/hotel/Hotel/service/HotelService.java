package com.test.hotel.Hotel.service;

import com.test.hotel.Hotel.entities.Hotel;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * The interface Hotel service.
 */
public interface HotelService {
    /**
     * Create hotel hotel.
     *
     * @param hotel the hotel
     * @return the hotel
     */
    public Hotel createHotel(Hotel hotel);

    /**
     * Delete hotel hotel.
     *
     * @param id the id
     * @return the hotel
     */
    public void deleteHotel(String id);

    /**
     * Gets .
     *
     * @return the
     */
    public List<Hotel> getAllHotel();

    /**
     * Gets hotel.
     *
     * @param id the id
     * @return the hotel
     */
    public Hotel getHotel(String id);
}
