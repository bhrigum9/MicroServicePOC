package com.test.hotel.Hotel.service;

import com.test.hotel.Hotel.entities.Hotel;
import com.test.hotel.Hotel.exception.ResourceNotFoundException;
import com.test.hotel.Hotel.repository.HotelRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class HotelServiceImpl implements HotelService {

    @Autowired
    private HotelRepository hotelRepository;

    @Autowired
    private RestTemplate restTemplate;
    /**
     * @param hotel the hotel
     * @return
     */
    @Override
    public Hotel createHotel(Hotel hotel) {
        return hotelRepository.save(hotel);
    }

    /**
     * @param id the id
     * @return
     */
    @Override
    public void deleteHotel(String id) {
        hotelRepository.deleteById(id);
    }

    /**
     * @return
     */
    @Override
    public List<Hotel> getAllHotel() {
        return hotelRepository.findAll();
    }

    /**
     * @param id the id
     * @return
     */
    @Override
    public Hotel getHotel(String id) {
        Hotel hotel = hotelRepository.findById(id).orElseThrow(() -> new ResourceNotFoundException("The value not found in DB!!"));
        String url = "http://RATING-SERVICE/ratings/hotels/" + hotel.getId();
        ArrayList ratingByHotelIdList = restTemplate.getForObject(url, ArrayList.class);

        hotel.setRatings(ratingByHotelIdList);

        return hotel;
    }
}
