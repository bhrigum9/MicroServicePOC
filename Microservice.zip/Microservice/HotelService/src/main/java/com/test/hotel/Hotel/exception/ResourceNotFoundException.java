package com.test.hotel.Hotel.exception;

/**
 * The type Resource not found exception.
 */
public class ResourceNotFoundException extends  RuntimeException{

    /**
     * Instantiates a new Resource not found exception.
     *
     * @param s the s
     */
    public ResourceNotFoundException (String s){
        super(s);
    }

    /**
     * Instantiates a new Resource not found exception.
     */
    public ResourceNotFoundException(){
        super("Resource Not found!!");
    }
}
