package com.test.mircroservice.userservice.UserService.service;

import com.test.mircroservice.userservice.UserService.entities.Hotel;
import com.test.mircroservice.userservice.UserService.entities.Ratings;
import com.test.mircroservice.userservice.UserService.entities.User;
import com.test.mircroservice.userservice.UserService.exception.ResourceNotFoundException;
import com.test.mircroservice.userservice.UserService.external.service.HotelService;
import com.test.mircroservice.userservice.UserService.external.service.RatingService;
import com.test.mircroservice.userservice.UserService.repositories.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.CollectionUtils;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collector;
import java.util.stream.Collectors;

@Service
public class UserServiceImpl implements UserService{
    @Autowired
    private UserRepository userRepository;
    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private HotelService hotelService;

    @Autowired
    private RatingService ratingService;

    private Logger logger = LoggerFactory.getLogger(UserServiceImpl.class);


    /**
     * @param user the user
     * @return
     */
    @Override
    public User saveUser(User user) {
        String randomId = UUID.randomUUID().toString();
        user.setUserId(randomId);
        return userRepository.save(user);
    }

    /**
     * @param userId the user id
     * @return
     */
    @Override
    public User getUser(String userId) {
        User user = userRepository.findById(userId).orElseThrow(() -> new ResourceNotFoundException("UserId not found :" + userId));

        //BY restTemplate approach
        //String url ="http://RATING-SERVICE/ratings/users/"+user.getUserId();
        //Ratings[] ratingByUserId = restTemplate.getForObject(url, Ratings[].class);
        //List<Ratings> ratings = Arrays.stream(ratingByUserId).toList();

        //By using FeignClient  approach
        List<Ratings> ratingByUserId = ratingService.getRatingByUserId(user.getUserId());

        List<Ratings> ratingList = ratingByUserId.stream().map(rating ->
            {
                // uri = "http://HOTEL-SERVICE/hotels/" + rating.getHotelId();
                //Using Rest Template Approach
                //Hotel hotel = restTemplate.getForObject(uri, Hotel.class);

                //By using FeignClient  approach
                Hotel hotel =hotelService.getHotel(rating.getHotelId());

                rating.setHotel(hotel);
                return rating;
            }).collect(Collectors.toList());
        user.setRatings(ratingList);
        return user;
    }

    /**
     * @return
     */
    @Override
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * @param userId the user id
     */
    @Override
    public void deleteUser(String userId) {
        logger.info("the userId value to delete :" +userId);
        List<Ratings> ratingsByUserId = ratingService.getRatingByUserId(userId);
        if (!CollectionUtils.isEmpty(ratingsByUserId)) {
            logger.info("the list of ratingsByUserId : " +ratingsByUserId.toString());
            ratingsByUserId.stream().forEach(rating -> {
                    logger.info("the rating id for deletion : "+ rating.getId());
                    ratingService.deleteById(rating.getId());
                }
            );
            userRepository.deleteById(userId);
        }
    }

    /**
     * @param user the user
     * @return
     */
    @Override
    public User updateUser(User user) {
        return userRepository.save(user);
    }
}
