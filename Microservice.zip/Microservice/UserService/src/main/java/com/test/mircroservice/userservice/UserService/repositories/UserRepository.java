package com.test.mircroservice.userservice.UserService.repositories;

import com.test.mircroservice.userservice.UserService.entities.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,String> {
}
