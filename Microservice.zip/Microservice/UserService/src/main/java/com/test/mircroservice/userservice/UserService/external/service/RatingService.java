package com.test.mircroservice.userservice.UserService.external.service;

import com.test.mircroservice.userservice.UserService.entities.Hotel;
import com.test.mircroservice.userservice.UserService.entities.Ratings;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import java.util.List;

@FeignClient(name="RATING-SERVICE")
public interface RatingService {
    @GetMapping("/ratings/users/{userId}")
    public List<Ratings> getRatingByUserId(@PathVariable String userId);

    @DeleteMapping("/ratings/{id}")
    public void deleteById(@PathVariable("id") String id);

}
