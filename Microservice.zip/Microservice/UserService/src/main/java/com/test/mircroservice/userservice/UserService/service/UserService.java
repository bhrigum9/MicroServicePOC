package com.test.mircroservice.userservice.UserService.service;

import com.test.mircroservice.userservice.UserService.entities.User;

import java.util.List;

/**
 * The interface User service.
 */
public interface UserService {
    /**
     * Save user user.
     *
     * @param user the user
     * @return the user
     */
    User saveUser(User user);

    /**
     * Gets user.
     *
     * @param userId the user id
     * @return the user
     */
    User getUser(String userId);

    /**
     * Gets all users.
     *
     * @return the all users
     */
    List<User> getAllUsers();

    /**
     * Delete user.
     *
     * @param userId the user id
     */
    void deleteUser(String userId);

    /**
     * Update user user.
     *
     * @param user the user
     * @return the user
     */
    User updateUser(User user);


}
